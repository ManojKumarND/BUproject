package com.insurance.claim;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginPage extends  HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		RequestDispatcher rd=null;
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String str=null;
		try {
			con=Connect.getconnect();
			/*System.out.println("into try");
			 Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg620","training620");
			    System.out.println("connected");*/
	   //  System.out.println(con);
		 String uname=request.getParameter("userName");
		 String password=request.getParameter("userPwd");
		 //System.out.println(uname);
		// System.out.println(password);
		 String sql="select roleid from insurance where userid=? and password=?";
		 
			pst=con.prepareStatement(sql);
			pst.setString(1,uname);
			pst.setString(2,password);
			rs=pst.executeQuery();
		
		
		 while(rs.next())
		 {
			 str=rs.getString(1); 
		 }
		// System.out.println(str);
		 if(str.equals("administrator"))
		 {
			request.getRequestDispatcher("/admin.jsp").include(request, response);
		 }
		 else if(str.equals("customer"))
		 {
			request.getRequestDispatcher("/user.jsp").include(request, response);
		 }
		 else if(str.equals("agent111"))
		 {
			request.getRequestDispatcher("/agent.jsp").include(request, response);
		 }
		 
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}
