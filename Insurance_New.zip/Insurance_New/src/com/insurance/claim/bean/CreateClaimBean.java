package com.insurance.claim.bean;

public class CreateClaimBean
{

}
