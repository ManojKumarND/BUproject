package com.insurance.claim.controller;

public class NewclaimController {

}
