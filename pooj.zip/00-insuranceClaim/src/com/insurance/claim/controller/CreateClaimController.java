package com.insurance.claim.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.insurance.claim.Connect;
import com.insurance.claim.bean.CreateClaimBean;
import com.insurance.claim.service.CreateClaimService;

public class CreateClaimController {

	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		response.setContentType("text/html");
		RequestDispatcher rd=null;
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String str=null;
		CreateClaimBean claimbean=new CreateClaimBean();
		CreateClaimService ccservice=new CreateClaimService();
		//con=Connect.getconnect();
		
		String reason=request.getParameter("reason");
		 String location=request.getParameter("location");
		 String city=request.getParameter("city");
		 String state=request.getParameter("state");
		 int zip=Integer.parseInt(request.getParameter("zip"));
		 String type=request.getParameter("type");
		 
		 claimbean.setReason(reason);
		 claimbean.setLocation(location);
		 claimbean.setCity(city);
		 claimbean.setState(state);
		 claimbean.setZip(zip);
		 claimbean.setType(type);
		
		int updateCount=0;
		updateCount=ccservice.createClaim(claimbean);
		
			}
			
	
}
